import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smart-assistant-new-register',
  templateUrl: './smart-assistant-new-register.component.html',
  styleUrls: ['./smart-assistant-new-register.component.css']
})
export class SmartAssistantNewRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
