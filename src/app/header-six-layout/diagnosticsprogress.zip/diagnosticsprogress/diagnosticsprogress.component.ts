import { Component, OnInit } from '@angular/core';
import { UserService } from '../../providers/user.service';
import { ToastrService } from 'ngx-toastr';
import { Router,ActivatedRoute } from '@angular/router'; 
import { MatRadioChange } from '@angular/material';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import {Sort} from '@angular/material';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { ConfirmationDialogComponent } from '../../confirmation-popup/confirmation-dialog/confirmation-dialog.component'
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

declare var $
declare var jsPDF: any; 

@Component({
	selector: 'app-diagnosticsprogress',
	templateUrl: './diagnosticsprogress.component.html',
	styleUrls: ['./diagnosticsprogress.component.css'],
	providers: [UserService]
})
export class DiagnosticsprogressComponent implements OnInit {
	headerClicked
	diagnosticsData
	totalPrescriptions
	totalSales
	totalSalesAmount
	totalConversion
	totalSalesPerPres
	totalSalesWalkin
	totalSalesDoctorPlusWalkin
	totalProfit
	loading
	dataArray
	constructor(private userService: UserService) { }

	ngOnInit() {
		console.log("sdh s ds dada j")
		this.diagnosticsData = JSON.parse(localStorage['smartDiagnosticsDetails'])
		this.dataArray = []
		this.totalPrescriptions = 0
		this.totalSales = 0
		this.totalSalesAmount = 0
		this.totalConversion = 0
		this.totalSalesPerPres = 0
		this.totalSalesWalkin = 0
		this.totalProfit= 0
		this.totalSalesDoctorPlusWalkin = 0
		this.getDocData()
	}
	getTableHeaderClass(id){
		if(this.headerClicked == id){
			return 'selected'
		}else{
			return ''
		}
	}

	setTableHeaderClass(id){
		this.headerClicked = id
	}

	getData(data){
        if(data % 1 != 0){
            return data.toFixed(2)
        }else{
            return data
        }
    }
    
    getDoctorName(id){
        for (var i = 0; i < this.diagnosticsData.doctorsRegisteredForSmartClinic.length; i++) {
            if(this.diagnosticsData.doctorsRegisteredForSmartClinic[i]._id == id){
                return (this.diagnosticsData.doctorsRegisteredForSmartClinic[i].first_name)
            }
        }
    }

	getDocData(){
		var ob ={
			smart_diagnostics_id : this.diagnosticsData.dataSmartDiagnostics._id 
		}
		this.loading = true
		console.log("bhsadbhas s djd ")
		this.userService.DiagnosticsProgressToday(ob).subscribe(data => {
			console.log(data)
			if (data.response == true) {
				this.dataArray = data.data
				// for (var i = 0; i < this.dataArray.length; i++) {
				// 	this.dataArray[i].true_sales = []
				// 	this.dataArray[i].false_sales = []
				// 	this.dataArray[i].total_sales_amount = 0
				// 	this.dataArray[i].sales_per_pres = 0
				// 	for (var j = 0; j < this.dataArray[i].total_sales.length; j++) {
				// 		if(this.dataArray[i].total_sales[j].diagnostics){
				// 			this.dataArray[i].total_sales_amount = this.dataArray[i].total_sales_amount + this.dataArray[i].total_sales[j].total_amount 
				// 			// this.totalProfit = this.totalProfit + (this.dataArray[i].total_sales[j].total_amount - this.dataArray[i].total_sales[j].pharmacy_cost)
				// 			this.dataArray[i].true_sales.push(this.dataArray[i].total_sales[j])
				// 		}else{
				// 			this.dataArray[i].false_sales.push(this.dataArray[i].total_sales[j])
				// 		}
				// 	}
				// 	this.dataArray[i].conversion = this.getData((this.dataArray[i].true_sales.length * 100) / this.dataArray[i].total_sales.length)
				// 	if(this.dataArray[i].true_sales.length>0){
				// 		this.dataArray[i].sales_per_pres = parseFloat(this.getData(this.dataArray[i].total_sales_amount / this.dataArray[i].true_sales.length))
				// 	}
				// }
				// for (var i = 0; i < this.dataArray.length; i++) {
				// 	this.totalPrescriptions = this.totalPrescriptions + this.dataArray[i].total_sales.length
				// 	this.totalSales = this.totalSales + this.dataArray[i].true_sales.length
				// 	this.totalSalesAmount = this.totalSalesAmount + this.dataArray[i].total_sales_amount
				// }
				// this.totalConversion = this.getData((this.totalSales * 100) / this.totalPrescriptions)
				// this.totalSalesPerPres = this.totalSalesPerPres + parseFloat(this.getData(this.totalSalesAmount / this.totalSales))
				// //calculate amount for walkin patients//
				// for (var i = 0; i < data.data1.length; i++) {
				// 	this.totalProfit = this.totalProfit + (data.data1[i].total_amount - data.data1[i].cost_amount)
				// 	this.totalSalesWalkin = this.totalSalesWalkin + data.data1[i].total_amount
				// }
				// this.totalSalesDoctorPlusWalkin = this.totalSalesAmount + this.totalSalesWalkin
			} 
			this.loading = false        
		}, err => {
			console.log(err);
		})
	}

	exportPdf(){
        var head = [
            { title: 'Doctor Name', dataKey: "Doctor"},
            { title: 'Prescriptions', dataKey: "Prescriptions"},
            { title: 'Sales Orders', dataKey: "SalesOrders"},
            { title: 'Sales Amount', dataKey: "SalesAmount"},
            { title: 'Conversion (%)', dataKey: "Conversion"},
            { title: 'Sales/prescription (Rs)', dataKey: "salesPerPrescription"}
        ]
        var csvData = []
        var totalDuration
        var dates = []
        for (var i = 0; i < this.dataArray.length; i++) {
            var ob ;
            ob = {}
            ob.id = i+1
            //var date = this.stockValuation[i].createdAt.split('T')
            //ob.updateAt = date[0] + " " +date[1].substr(0,5)
            ob.Doctor = this.getDoctorName(this.dataArray[i]._id)
            ob.Prescriptions = this.dataArray[i].total_sales.length
            ob.SalesOrders = this.dataArray[i].true_sales.length
            ob.SalesAmount = this.dataArray[i].total_sales_amount
            ob.Conversion = this.dataArray[i].conversion
            ob.salesPerPrescription = this.dataArray[i].sales_per_pres
            csvData.push(ob)
        }
        csvData.push({
        	Doctor: "Clinic Aggregates",
        	Prescriptions: this.totalPrescriptions,
			SalesOrders: this.totalSales,
			SalesAmount: this.checkIsNan(this.totalSalesAmount) + '+' + this.checkIsNan(this.totalSalesWalkin)+'(NPS)'+ '=' + this.checkIsNan(this.totalSalesDoctorPlusWalkin),
			Conversion: this.checkIsNan(this.totalConversion),
			salesPerPrescription: this.checkIsNan(this.totalSalesPerPres)
        })
        var date = new Date().toJSON().toString().substr(0,10)
        var doc = new jsPDF('p', 'pt');
        doc.autoTable(head, csvData, {
            theme: 'grid',
            styles: {
                overflow: 'linebreak',
            },
            margin: 5,
            fontSize:8,
            tableWidth: 'auto',
            showHeader: 'everyPage'
        });
      	doc.save('Progress-Today'+"("+date+")");
    }

    checkIsNan(data){
    	if(isNaN(data)){
    		return 0
    	}else{
    		return data
    	}
    }

}
