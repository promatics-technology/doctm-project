import { CustomPipesPipe } from './custom-pipes.pipe';

describe('CustomPipesPipe', () => {
  it('create an instance', () => {
    const pipe = new CustomPipesPipe();
    expect(pipe).toBeTruthy();
  });
});
